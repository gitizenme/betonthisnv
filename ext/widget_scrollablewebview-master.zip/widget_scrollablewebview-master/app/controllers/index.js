$.swv.urlArray = [ "http://www.cnn.com", "http://www.google.com", "http://en.wikipedia.org/wiki/Main_Page" ];
$.swv.currentPage = 1;
$.index.open();
