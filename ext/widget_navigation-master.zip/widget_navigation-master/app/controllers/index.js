$.index.open();
var win1 = Alloy.createController('win1').getView();
$.navgroup.open(win1);
Alloy.Globals.navGroup = $.navgroup;
