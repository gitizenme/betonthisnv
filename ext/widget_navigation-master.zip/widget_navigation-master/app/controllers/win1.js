function ButtonClick(e) {
    var win2 = Alloy.createController('win2').getView();
    Alloy.Globals.navGroup.open(win2);
}