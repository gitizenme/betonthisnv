function ButtonClick(e) {
    Alloy.Globals.navGroup.home();
}