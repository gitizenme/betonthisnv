function ButtonClick(e) {
    var win3 = Alloy.createController('win3').getView();
    Alloy.Globals.navGroup.open(win3);
}